
package com.ibm.rishabh.businesslisting0160225105920.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.ibm.rishabh.businesslisting0160225105920.R;
import ibmmobileappbuilder.actions.ActivityIntentLauncher;
import ibmmobileappbuilder.actions.OpenUriAction;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.image.ImageLoader;
import ibmmobileappbuilder.util.image.PicassoImageLoader;
import ibmmobileappbuilder.util.StringUtils;
import java.net.URL;
import static ibmmobileappbuilder.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.rishabh.businesslisting0160225105920.ds.StoresDSItem;
import com.ibm.rishabh.businesslisting0160225105920.ds.StoresDS;

public class StoresMapDetailFragment extends ibmmobileappbuilder.ui.DetailFragment<StoresDSItem>  {

    private Datasource<StoresDSItem> datasource;
    public static StoresMapDetailFragment newInstance(Bundle args){
        StoresMapDetailFragment fr = new StoresMapDetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public StoresMapDetailFragment(){
        super();
    }

    @Override
    public Datasource<StoresDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = StoresDS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.storesmapdetail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final StoresDSItem item, View view) {
        
        ImageView view0 = (ImageView) view.findViewById(R.id.view0);
        URL view0Media = ((AppNowDatasource) getDatasource()).getImageUrl(item.picture);
        if(view0Media != null){
          ImageLoader imageLoader = new PicassoImageLoader(view0.getContext());
          imageLoader.load(imageLoaderRequest()
                                   .withPath(view0Media.toExternalForm())
                                   .withTargetView(view0)
                                   .fit()
                                   .build()
                    );
        	
        } else {
          view0.setImageDrawable(null);
        }
        if (item.rating != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(item.rating.toString() + " ★");
            
        }
        if (item.reviewedon != null){
            
            TextView view2 = (TextView) view.findViewById(R.id.view2);
            view2.setText(DateFormat.getMediumDateFormat(getActivity()).format(item.reviewedon));
            
        }
        if (item.comments != null){
            
            TextView view4 = (TextView) view.findViewById(R.id.view4);
            view4.setText(item.comments);
            bindAction(view4, new OpenUriAction(
            new ActivityIntentLauncher()
            , "<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3554.0195786822082!2d75.89174411430608!3d27.02954726155916!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396daffbd3cd5959%3A0xb"));
        }
    }

    @Override
    protected void onShow(StoresDSItem item) {
        // set the title for this fragment
        getActivity().setTitle(item.store);
    }
}

